---
name: Bug Report
about: Report a bug or unexpected behavior
title: '[BUG] '
labels: bug
assignees: ''
---

## Bug Description
<!-- A clear and concise description of what the bug is -->

## Steps to Reproduce
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

## Expected Behavior
<!-- What you expected to happen -->

## Actual Behavior
<!-- What actually happened -->

## Screenshots
<!-- If applicable, add screenshots to help explain the problem -->

## Environment
- **Component**: Backend / Frontend / Database
- **Java Version**: 
- **Node/Bun Version**: 
- **PostgreSQL Version**: 
- **OS**: 
- **Browser** (if frontend): 

## Error Logs
```
Paste any relevant error logs here
```

## Additional Context
<!-- Add any other context about the problem here -->

## Related Phase
<!-- Which curriculum phase were you working on when you encountered this? -->
Phase: ___
